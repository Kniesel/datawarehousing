Inverted Exam for Datawarehousing, ITM14

Johanna Kirchmaier
Tabea Halmschlager

09.07.2016