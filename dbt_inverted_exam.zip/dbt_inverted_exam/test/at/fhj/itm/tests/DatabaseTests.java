package at.fhj.itm.tests;


import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.junit.Test;

import at.fhj.itm.utils.ConnectionFactory;

public class DatabaseTests {

	@Test
	public void testConnectionFactory() throws SQLException 
	{
		Connection c = ConnectionFactory.getConnection();
		Statement s = c.createStatement();
		s.execute("SELECT COUNT(*) FROM MOVIE");
		
		// Wenn keine Exception geworfen wird ist der Test erfolgreich
	}

	
}
