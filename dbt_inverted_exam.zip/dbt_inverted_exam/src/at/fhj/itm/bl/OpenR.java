package at.fhj.itm.bl;

import at.fhj.itm.dao.CustomerDAO;
import at.fhj.itm.dao.HallDAO;

/**
 * RFID-Readers are located next to the doors in ACME, if a RFID-Tag 
 * is read and the employee has access to the room, a URL is sent to 
 * a server and the door unlocks
 * 
 * @author Halmschlager Tabea
 *
 */
public class OpenR {

	private String rfid;
	private int room_id;
	private String room_name;
	private String site;

	private CustomerDAO employee = new CustomerDAO();
	private HallDAO rdao = new HallDAO();
	private URLGenerator urlgen = new URLGenerator();
	
	
	public OpenR() {}

	/**
	 * Checks if the employee that is trying to open the door has access to this room 
	 * and if so generates the url to unlock it
	 * 
	 * @param data concaternation of site, room and rfid emitted by the RFID reader
	 */
	public void open(String data) {
		
		site = data.split("/", 2)[0];
		room_name = data.split("/", 2)[1].split(":", 2)[0];
		rfid = data.split(":", 2)[1];
		
		room_id = rdao.getHall(site, room_name).id;
		
		if (employee.hasAccess(rfid, room_id)){
			urlgen.generate(room_name, site);
		}
		else 
			System.out.println("Employee " + rfid + " is not allowed in " + room_name + ".\n");
		
	}
}
